
const Miestilo = {
  fill: '#00ff00',
  fontFamily: 'monospace',
  lineSpacing: 4
};

export default Miestilo;

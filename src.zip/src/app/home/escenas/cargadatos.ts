import Constantes from "../constantes";
import Phaser from "phaser";

export default class CargaDatos extends Phaser.Scene {

    private barraC!: Phaser.GameObjects.Graphics; //barra de carga
    //Las ! en las variables indican que ese valor no puede ser ni null ni undefined, siempre ha de tener un valor

    constructor() {
        super('CargaDatos');
    }

    preload() {
        this.cameras.main.setBackgroundColor(0x0000FF); //se configura la cámara
        this.creaBarras();
        console.log("Enviando mensaje al LOG del navegador");

        //Declaramos variables utilizadas en el evento load
        var barraP!: Phaser.GameObjects.Graphics; //barra de progreso
        var anchoCameras = this.cameras.main.width;
        var altoCameras = this.cameras.main.height;
        barraP = this.add.graphics();

        //Listener mientras (PROGRESS) se cargan los assets. No usa función lambda
        this.load.on(
            'progress',
            function (value: number) {
                barraP.clear();
                barraP.fillStyle(0x125555, 1);
                barraP.fillRect(
                    anchoCameras / 4,
                    altoCameras / 2 - 16,
                    (anchoCameras / 2) * value, 
                    16);
            },
            this
        );
        

        //Listener cuando se hayan cargado (COMPLETE) todos los Assets. Usa función lambda
        this.load.on(
            'complete', () => { //arrow-function o función lambda
                this.scene.start(Constantes.ESCENAS.MENU); //Salta a la escena de Menú
            },

        );


        //CARGA DE ASSETS
       
        //Mapas
        this.load.tilemapTiledJSON(Constantes.MAPAS.NIVEL1.TILEMAPJSON, 'assets/mapas/Principio/maparuinasv2.json');
        this.load.image(Constantes.MAPAS.TILESET, 'assets/mapas/Principio/maparuinas.png');

        //Fondos e imágenes
        this.load.image(Constantes.FONDOS.LOGO, 'assets/imagenes/menulogo.png');

        //Fuente
        this.load.bitmapFont(Constantes.FUENTES.NOMBREFUENTE, 'assets/fuentes/atari-sunset.png', 'assets/fuentes/atari-sunset.xml');
        //Atlas Jugador
        this.load.atlas(Constantes.JUGADOR.ID, 'assets/imagenes/jugador/spritesheet.png', 'assets/imagenes/jugador/spritesheet.json');
        this.load.atlas(Constantes.GUARDAR.ID, 'assets/imagenes/miscelaneo/guardar/spritesheet.png', 'assets/imagenes/miscelaneo/guardar/spritesheet.json');
        
        
        //Atlas Enemigos
        this.load.atlas(Constantes.FLOWEY.ID, 'assets/imagenes/enemigos/flowey/spritesheet.png', 'assets/imagenes/enemigos/flowey/spritesheet.json');
        this.load.atlas(Constantes.ENEMIGO01.ID, 'assets/imagenes/enemigos/varios/spritesheetM01.png', 'assets/imagenes/enemigos/varios/spritesheetM01.json');
        this.load.atlas(Constantes.ENEMIGO02.ID, 'assets/imagenes/enemigos/varios/spritesheetM02.png', 'assets/imagenes/enemigos/varios/spritesheetM02.json');
        this.load.atlas(Constantes.ENEMIGO03.ID, 'assets/imagenes/enemigos/varios/spritesheetM03.png', 'assets/imagenes/enemigos/varios/spritesheetM03.json');

        //Atlas Enemigo - Mynock
        
        //Carga de sonidos
        this.load.audio('musica', 'assets/audio/musica/ruinas.mp3');
        this.load.audio('menunusic', 'assets/audio/musica/menu.mp3');
        this.load.audio('laser', 'assets/audio/musica/laser.mp3');
    }
    private creaBarras(): void {
        this.barraC = this.add.graphics();
        this.barraC.fillStyle(0xffffff, 1);//color,alfa


        this.barraC.fillRect(
            this.cameras.main.width / 4 - 2, //x de rectángulo
            this.cameras.main.height / 2 - 18,//y de rectángulo
            this.cameras.main.width / 2 + 4, //ancho
            20 //alto
        );
    }

    
        


}